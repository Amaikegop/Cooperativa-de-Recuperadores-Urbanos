
public class Imagen {
	
	// Clase imaginaria para subir una imagen
	
	private String foto;
	private String tipo;
	
	public Imagen (String foto, String tipo) {
		this.foto = foto;
		this.tipo = tipo;
	}
}
